<?php
session_start();

if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace('https://jottar.000webhostapp.com/trabalhoweb');
    </script>
    ";
    
}

?>